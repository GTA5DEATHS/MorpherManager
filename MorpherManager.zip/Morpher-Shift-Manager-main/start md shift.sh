#!/bin/bash
python mdshiftmanager.py
